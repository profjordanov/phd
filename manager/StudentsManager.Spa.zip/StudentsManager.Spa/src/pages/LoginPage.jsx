import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import loginImage from '../assets/login/login-step1.jpg';

function LoginPage() {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    rememberMe: false
  });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.email) {
      newErrors.email = 'Email е задължителен';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Невалиден email адрес';
    }

    if (!formData.password) {
      newErrors.password = 'Паролата е задължителна';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Паролата трябва да е поне 6 символа';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      // Here you would normally make an API call
      console.log('Form submitted:', formData);
      // Simulate successful login
      navigate('/');
    }
  };

  return (
    <div className="total-wrap-content">
      <div className="login-section">
        <div className="main-inner-content-wrap">
          <div className="login-title-wrap anim-elem top">
            <h1 className="title-big">Вход</h1>
          </div>
          <div className="login-grid">
            <div className="login-grid-wrap">
              <div className="login-image-item anim-elem bottom">
                <div 
                  className="bg-image" 
                  style={{ backgroundImage: `url(${loginImage})` }}
                />
              </div>
              <div className="login-content-item anim-elem top">
                <div className="login-content-item-wrap">
                  <form 
                    className="login-form" 
                    id="login-form" 
                    autoComplete="off"
                    onSubmit={handleSubmit}
                  >
                    <div className="form-row required">
                      <label htmlFor="email" className="label-form-fld">E-mail</label>
                      <input 
                        type="text" 
                        className={`form-fld ${errors.email ? 'error' : ''}`}
                        id="email" 
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                      />
                      <div className="border-bottom"></div>
                      <div className="tooltip-div">
                        {errors.email && <span className="error-message">{errors.email}</span>}
                      </div>
                    </div>
                    <div className="form-row required">
                      <label htmlFor="password" className="label-form-fld">Парола</label>
                      <input 
                        type="password" 
                        className={`form-fld ${errors.password ? 'error' : ''}`}
                        id="password" 
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                      />
                      <div className="border-bottom"></div>
                      {errors.password && (
                        <div className="tooltip-div">
                          <span className="error-message">{errors.password}</span>
                        </div>
                      )}
                    </div>
                    <div className="form-row row-checkbox">
                      <input 
                        type="checkbox" 
                        value="1" 
                        className="form-fld" 
                        id="data-save" 
                        name="rememberMe"
                        checked={formData.rememberMe}
                        onChange={handleChange}
                      />
                      <label htmlFor="data-save" className="label-form-fld">Запомни ме</label>
                    </div>
                    <div className="form-row btn-row">
                      <button 
                        className="submit-btn" 
                        type="submit" 
                        id="submit-btn"
                      >
                        ВХОД
                      </button>
                    </div>
                  </form>
                  <div className="login-bottom-row">
                    <div className="forgotten-password-row">
                    </div>
                    <div className="registration-row">
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
