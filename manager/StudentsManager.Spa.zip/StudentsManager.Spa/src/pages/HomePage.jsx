import { useState, useCallback } from 'react';
import FullPage from '../components/FullPage/FullPage';
import {
  IntroSection,
  TestSection,
  ChatbotSection,
} from '../components/HomeSections';

function HomePage() {
  const [activeSection, setActiveSection] = useState(0);

  const handleSectionChange = useCallback((index) => {
    setActiveSection(index);
  }, []);

  const scrollToNextSection = useCallback(() => {
    // This will be handled by the FullPage component
    // We trigger it via a custom event or ref
  }, []);

  return (
    <div className="home-page">
      <FullPage onSectionChange={handleSectionChange}>
        <IntroSection onScrollDown={scrollToNextSection} />
        <TestSection />
        <ChatbotSection />
      </FullPage>
    </div>
  );
}

export default HomePage;
