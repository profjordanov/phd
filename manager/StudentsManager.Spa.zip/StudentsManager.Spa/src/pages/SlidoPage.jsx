export default function SlidoPage() {
	return <div>Slido Page</div>;
}
