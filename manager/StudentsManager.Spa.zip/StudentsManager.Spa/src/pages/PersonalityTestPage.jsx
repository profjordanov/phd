import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './PersonalityTestPage.css';

// Import questions from JSON (in real app, you'd fetch this)
const questions = [
  {
    id: 1,
    text: "Предпочитам да работя самостоятелно",
    options: [
      { value: 1, text: "Напълно несъгласен" },
      { value: 2, text: "Несъгласен" },
      { value: 3, text: "Неутрален" },
      { value: 4, text: "Съгласен" },
      { value: 5, text: "Напълно съгласен" }
    ],
    category: "action"
  },
  {
    id: 2,
    text: "Обичам да работя с хора",
    options: [
      { value: 1, text: "Напълно несъгласен" },
      { value: 2, text: "Несъгласен" },
      { value: 3, text: "Неутрален" },
      { value: 4, text: "Съгласен" },
      { value: 5, text: "Напълно съгласен" }
    ],
    category: "people"
  },
  {
    id: 3,
    text: "Харесва ми да анализирам данни",
    options: [
      { value: 1, text: "Напълно несъгласен" },
      { value: 2, text: "Несъгласен" },
      { value: 3, text: "Неутрален" },
      { value: 4, text: "Съгласен" },
      { value: 5, text: "Напълно съгласен" }
    ],
    category: "process"
  },
  {
    id: 4,
    text: "Обичам да измислям нови идеи",
    options: [
      { value: 1, text: "Напълно несъгласен" },
      { value: 2, text: "Несъгласен" },
      { value: 3, text: "Неутрален" },
      { value: 4, text: "Съгласен" },
      { value: 5, text: "Напълно съгласен" }
    ],
    category: "idea"
  }
];

function PersonalityTestPage() {
  const [hasStarted, setHasStarted] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [showResults, setShowResults] = useState(false);
  const navigate = useNavigate();

  const startTest = () => {
    setHasStarted(true);
  };

  const handleAnswer = (questionId, value, category) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: { value, category }
    }));
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      setShowResults(true);
    }
  };

  const prevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
    }
  };

  const calculateResults = () => {
    const stats = {
      action: 0,
      process: 0,
      people: 0,
      idea: 0
    };

    Object.values(answers).forEach(answer => {
      stats[answer.category] += answer.value;
    });

    return stats;
  };

  if (showResults) {
    return <TestResults results={calculateResults()} onRetake={() => {
      setHasStarted(false);
      setCurrentQuestion(0);
      setAnswers({});
      setShowResults(false);
    }} />;
  }

  if (!hasStarted) {
    return <TestIntro onStart={startTest} />;
  }

  const question = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  return (
    <div className="personality-test-page">
      <div className="test-container">
        <div className="test-progress">
          <div 
            className="test-progress-bar" 
            style={{ width: `${progress}%` }}
          />
        </div>
        
        <div className="test-question-counter">
          Въпрос {currentQuestion + 1} от {questions.length}
        </div>

        <div className="test-question">
          <h2 className="question-text">{question.text}</h2>
          
          <div className="question-options">
            {question.options.map(option => (
              <button
                key={option.value}
                className={`option-btn ${answers[question.id]?.value === option.value ? 'selected' : ''}`}
                onClick={() => handleAnswer(question.id, option.value, question.category)}
              >
                {option.text}
              </button>
            ))}
          </div>
        </div>

        <div className="test-navigation">
          <button 
            className="nav-btn prev"
            onClick={prevQuestion}
            disabled={currentQuestion === 0}
          >
            ← Назад
          </button>
          <button 
            className="nav-btn next"
            onClick={nextQuestion}
            disabled={!answers[question.id]}
          >
            {currentQuestion === questions.length - 1 ? 'Завърши' : 'Напред →'}
          </button>
        </div>
      </div>
    </div>
  );
}

function TestIntro({ onStart }) {
  return (
    <div className="personality-test-page">
      <div className="test-intro-section">
        <div 
          className="bg-image" 
          style={{ backgroundImage: "url('/webroot/images/test/test-bg.jpg')" }}
        />
        <div className="test-intro-content">
          <div className="test-intro-box">
            <div className="addition-txt-box">
              <span className="p-huge lightGrey addition-txt">РАЗБЕРИ</span>
            </div>
            <h1 className="test-intro-title">
              Какво те прави <strong className="red">#РАЗЛИЧЕН</strong>?
            </h1>
            <p className="test-intro-text">
              Този тест ще ти помогне да откриеш своите силни страни и ще те насочи какви позиции са най-подходящи за теб.
            </p>
            <div className="test-intro-features">
              <div className="feature-item">
                <span className="feature-icon">⏱️</span>
                <span>5-10 минути</span>
              </div>
              <div className="feature-item">
                <span className="feature-icon">📝</span>
                <span>40 въпроса</span>
              </div>
              <div className="feature-item">
                <span className="feature-icon">🎯</span>
                <span>Персонални резултати</span>
              </div>
            </div>
            <button className="btn-start-test" onClick={onStart}>
              Започни теста
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function TestResults({ results, onRetake }) {
  const categories = [
    { key: 'action', name: 'Действие', color: '#e74c3c' },
    { key: 'process', name: 'Процес', color: '#3498db' },
    { key: 'people', name: 'Хора', color: '#2ecc71' },
    { key: 'idea', name: 'Идеи', color: '#f39c12' }
  ];

  const maxScore = Math.max(...Object.values(results));
  const dominantCategory = categories.find(
    cat => results[cat.key] === maxScore
  );

  return (
    <div className="personality-test-page">
      <div className="test-results-section">
        <div className="test-results-container">
          <h1 className="results-title">
            Твоите <strong className="red">резултати</strong>
          </h1>
          
          <div className="results-dominant">
            <p>Твоята доминираща характеристика е:</p>
            <h2 style={{ color: dominantCategory?.color }}>
              {dominantCategory?.name}
            </h2>
          </div>

          <div className="results-chart">
            {categories.map(cat => (
              <div key={cat.key} className="result-bar-container">
                <span className="result-label">{cat.name}</span>
                <div className="result-bar-wrapper">
                  <div 
                    className="result-bar"
                    style={{ 
                      width: `${(results[cat.key] / (questions.length * 5)) * 100}%`,
                      backgroundColor: cat.color
                    }}
                  />
                </div>
                <span className="result-value">{results[cat.key]}</span>
              </div>
            ))}
          </div>

          <div className="results-actions">
            <button className="btn-retake" onClick={onRetake}>
              Направи теста отново
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PersonalityTestPage;
