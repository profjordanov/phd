export default function ProfilePage() {
	return <div>Profile Page</div>;
}