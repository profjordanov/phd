import React, { useState, useEffect, useCallback } from 'react';
import { useQuestionReader } from '../hooks/useQuestionReader';
import { TypedText } from '../components/TypedText/TypedText';
import { OptionsButtons } from '../components/OptionsButtons/OptionsButtons';
import { ScaleInput } from '../components/ScaleInput/ScaleInput';
import { CitySelect } from '../components/CitySelect/CitySelect';
import { FinalForm } from '../components/FinalForm/FinalForm';
import { TextInput } from '../components/TextInput/TextInput';
import questionsJson from './js/questions.json';
import './ChatbotPage.css';

// Import images so Vite can process them
import defaultIntroBgImage from "../assets/career/intro-bg.jpg";
import defaultRobotImage from "../assets/career/intro-robot.png";
import defaultBubbleImage from "../assets/career/bubble.png";

export const ChatbotPage = ({
  submitUrl = '/api/chatbot/save_results',
  isLoggedIn = false,
  termsUrl,
  introBgImage = defaultIntroBgImage,
  robotImage = defaultRobotImage,
  bubbleImage = defaultBubbleImage,
  bottomBgImage = null // No image available yet
}) => {
  const [questionsData, setQuestionsData] = useState(questionsJson);
  const [answers, setAnswers] = useState([]);
  const [showControls, setShowControls] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [statusMessage, setStatusMessage] = useState(null);
  const [chatbotStarted, setChatbotStarted] = useState(false);

  const {
    currentQuestion,
    isComplete,
    initialize,
    getNextQuestion,
    setIsComplete
  } = useQuestionReader(questionsData, 'MAIN');

  // Initialize when component mounts
  useEffect(() => {
    if (questionsData) {
      initialize();
      getNextQuestion();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [questionsData]);

  const collectAnswer = useCallback((question, answer) => {
    const answerText = typeof answer === 'number' && question.options.length
      ? question.options[answer]?.text || String(answer)
      : String(answer);

    setAnswers(prev => [...prev, {
      question: question.text,
      answer: answerText
    }]);
  }, []);

  const handleAnswer = useCallback((answer) => {
    if (!currentQuestion || isSubmitting) return;

    collectAnswer(currentQuestion, answer);
    setShowControls(false);

    setTimeout(() => {
      getNextQuestion(typeof answer === 'number' ? answer : undefined);
    }, 1000);
  }, [currentQuestion, isSubmitting, collectAnswer, getNextQuestion]);

  const handleTypingComplete = useCallback(() => {
    setShowControls(true);
  }, []);

  const submitAnswers = async (formData) => {
    setIsSubmitting(true);

    try {
      const response = await fetch(submitUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          res: JSON.stringify(answers),
          ...(formData && !isLoggedIn ? formData : {})
        })
      });

      const data = await response.json();

      if (data.status === false) {
        setStatusMessage('В момента не можем да обработим вашите отговори!');
      } else {
        setStatusMessage('Отлично! Вашите отговори бяха изпратени.');
        setShowControls(false);
      }
    } catch {
      setStatusMessage('В момента не можем да обработим вашите отговори!');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDecline = () => {
    setStatusMessage('Както кажеш! Ако си промениш мнението, знаеш къде да ме намериш. ;)');
    setShowControls(false);
    setIsComplete(true);
  };

  // Helper functions to determine question type
  const isRangeQuestion = (q) => !!q.rangeOptions;
  const isOptionsQuestion = (q) => q.options.length > 0;
  const isCitySelect = (q) => q.topic === 'city';
  const isLastQuestion = (q) => q.topic === 'finish';
  const isOpenQuestion = (q) => !q.rangeOptions && q.options.length === 0 && q.topic !== 'finish';

  const renderControls = () => {
    if (!currentQuestion || !showControls) return null;

    if (isLastQuestion(currentQuestion)) {
      return (
        <FinalForm
          onSubmit={submitAnswers}
          onDecline={handleDecline}
          isLoggedIn={isLoggedIn}
          termsUrl={termsUrl}
        />
      );
    }

    if (isCitySelect(currentQuestion)) {
      return <CitySelect onSelect={handleAnswer} />;
    }

    if (isRangeQuestion(currentQuestion)) {
      return <ScaleInput onSelect={handleAnswer} />;
    }

    if (isOptionsQuestion(currentQuestion)) {
      return (
        <OptionsButtons
          options={currentQuestion.options}
          onSelect={handleAnswer}
        />
      );
    }

    if (isOpenQuestion(currentQuestion)) {
      return <TextInput onSubmit={handleAnswer} />;
    }

    return null;
  };

  if (!questionsData || !currentQuestion) {
    return <div className="chatbot-loading">Зареждане...</div>;
  }

  const handleStartChatbot = (e) => {
    e.preventDefault();
    setChatbotStarted(true);
  };

  return (
    <div className="total-wrap-content">
      <div className="robot-intro-section">
        <div className="career-intro-section">
          <div className="bg-image" style={{ backgroundImage: `url('${introBgImage}')` }}></div>
          <div className="career-main-wrap">
            <div className="intro-box-outer anim-block">
              <div className="intro-box anim-elem top-visibility done">
                <div className="intro-box-wrap">
                  <div className="intro-box-title-wrap">
                    <h1 className="intro-title">Един #футуристичен изпит</h1>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* JOBS CATEGORIES */}
        <div className="career-categories-section">
          <div className="robot-grid">
            <div className="career-main-wrap">
              <div className="categories-grid anim-block">
                <div className="categories-image-item">
                  <div className="categories-robot anim-elem top delay-03 done">
                    <img src={robotImage} alt="robot" className="template-image" />
                    <div className="speech-bubble anim-elem delay-09 done">
                      <div className="speech-bubble-inner">
                        <div className="speech-bubble-bg">
                          <img src={bubbleImage} alt="bubble" className="template-image" />
                        </div>
                        <div className="speech-bubble-text-wrap">
                          <span className="speech-bubble-text">Здравей!</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className={`categories-container-item anim-elem top done ${chatbotStarted ? 'done' : ''}`}>
                  <div className="categories-container-item-wrap">
                    {!chatbotStarted ? (
                      <div className="robot-text-item">
                        <div className="robot-text-title-wrap">
                          <h4 className="robot-text-title">
                            Запознай се с #ROBO
                          </h4>
                        </div>
                        <div className="robot-text-content">
                          <p>
                            твоят виртуален асистент, който ще те преведе през един кратък изпит.
                          </p>
                        </div>
                        <div className="robot-btn-wrap">
                          <a 
                            href="#" 
                            className="btn-mid btn-gray" 
                            onClick={handleStartChatbot}
                            data-title="Бъди <strong>#искрен</strong>"
                          >
                            ЗАПОЧНИ
                          </a>
                        </div>
                      </div>
                    ) : (
                      <div className="chatbot-page active" id="chatbot-page">
                        <div className="soge-young-chatbot" data-url={submitUrl}>
                          <div className="soge-question">
                            {statusMessage ? (
                              <TypedText text={statusMessage} />
                            ) : (
                              <TypedText
                                text={currentQuestion.text}
                                onComplete={handleTypingComplete}
                              />
                            )}
                          </div>
                          <div className="soge-answer" style={{ opacity: showControls ? 1 : 0 }}>
                            {renderControls()}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="template-bottom-section">
          <div className="bg-image" style={{ backgroundImage: `url('${bottomBgImage}')` }}></div>
        </div>
      </div>
    </div>
  );
};

export default ChatbotPage;
