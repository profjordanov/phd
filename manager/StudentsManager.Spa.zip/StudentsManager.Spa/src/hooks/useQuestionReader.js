import { useState, useCallback, useRef } from 'react';
import _ from 'lodash';

export function useQuestionReader(questionsData, mainGroup) {
  const [currentQuestion, setCurrentQuestion] = useState(null);
  const [isComplete, setIsComplete] = useState(false);
  const queueRef = useRef([]);
  const currentQuestionRef = useRef(null);

  const getQuestion = useCallback((id) => {
    return questionsData?.questions[id];
  }, [questionsData]);

  const initialize = useCallback(() => {
    if (!questionsData) return;
    
    const group = questionsData.questionGroups.groups[mainGroup];
    if (group) {
      queueRef.current = group.items
        .map(id => getQuestion(id))
        .filter((q) => q !== undefined);
    }
  }, [questionsData, mainGroup, getQuestion]);

  const addToQueue = useCallback((questions) => {
    queueRef.current = [...questions, ...queueRef.current];
  }, []);

  const getRangeReference = useCallback((rangeOptions, answer) => {
    const ranges = [0, ...(rangeOptions.ranges || [])];
    const matchRanges = _.filter(ranges, (r) => r <= answer);
    return rangeOptions.rangeRefs[matchRanges.length - 1] || '';
  }, []);

  const getOptionRef = useCallback((options, answerIndex) => {
    return options[answerIndex]?.ref || '';
  }, []);

  const getNextQuestion = useCallback((answer) => {
    if (!questionsData) return null;

    // Handle branching based on current question's answer
    // Use ref to get the latest currentQuestion without adding it to dependencies
    const question = currentQuestionRef.current;
    if (question) {
      let ref = '';

      if (question.rangeOptions && typeof answer === 'number') {
        ref = getRangeReference(question.rangeOptions, answer);
      } else if (question.options.length && typeof answer === 'number') {
        ref = getOptionRef(question.options, answer);
      }

      if (ref && questionsData.questionGroups.groups[ref]) {
        const newQuestions = questionsData.questionGroups.groups[ref].items
          .map(id => getQuestion(id))
          .filter((q) => q !== undefined);
        addToQueue(newQuestions);
      }
    }

    // Check if complete
    if (queueRef.current.length === 0) {
      setIsComplete(true);
      return null;
    }

    // Get next question from queue
    const next = queueRef.current.shift() || null;
    currentQuestionRef.current = next;
    setCurrentQuestion(next);
    return next;
  }, [questionsData, getQuestion, getRangeReference, getOptionRef, addToQueue]);

  return {
    currentQuestion,
    isComplete,
    initialize,
    getNextQuestion,
    setIsComplete
  };
}
