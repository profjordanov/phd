import React, { useState } from 'react';
import './TextInput.css';

export const TextInput = ({ onSubmit, placeholder = 'Въведете отговор...' }) => {
  const [value, setValue] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (value.trim()) {
      onSubmit(value.trim());
      setValue('');
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  return (
    <form className="text-input-form" onSubmit={handleSubmit}>
      <textarea
        className="text-input-field"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder={placeholder}
        rows={3}
      />
      <button 
        type="submit" 
        className="text-input-submit btn-mid btn-gray"
        disabled={!value.trim()}
      >
        ИЗПРАТИ
      </button>
    </form>
  );
};
