import React, { useEffect, useRef } from 'react';
import Typed from 'typed.js';

export const TypedText = ({ 
  text, 
  onComplete, 
  typeSpeed = 20 
}) => {
  const elementRef = useRef(null);
  const typedRef = useRef(null);

  useEffect(() => {
    if (elementRef.current) {
      // Destroy previous instance
      if (typedRef.current) {
        typedRef.current.destroy();
      }

      typedRef.current = new Typed(elementRef.current, {
        strings: [text],
        typeSpeed,
        showCursor: false,
        onComplete: () => onComplete?.()
      });
    }

    return () => {
      if (typedRef.current) {
        typedRef.current.destroy();
      }
    };
  }, [text, typeSpeed, onComplete]);

  return <div ref={elementRef} />;
};
