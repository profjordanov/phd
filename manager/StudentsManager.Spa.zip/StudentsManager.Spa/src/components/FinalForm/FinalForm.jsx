import React, { useState } from 'react';

export const FinalForm = ({
  onSubmit,
  onDecline,
  isLoggedIn,
  termsUrl = '/terms-and-conditions'
}) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [agreed, setAgreed] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const newErrors = {};
    
    if (!isLoggedIn) {
      if (!name.trim()) newErrors.name = 'Моля въведете име';
      if (!email.trim()) newErrors.email = 'Моля въведете имейл';
      else if (!/\S+@\S+\.\S+/.test(email)) newErrors.email = 'Невалиден имейл';
      if (!agreed) newErrors.agreed = 'Моля приемете условията';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      onSubmit({ name, email });
    }
  };

  if (isLoggedIn) {
    return (
      <div className="wrapper login-section chatbot">
        <form onSubmit={handleSubmit}>
          <div className="form-row btn-row chatbot">
            <button type="submit" className="submit-btn">Изпрати</button>
            <button type="button" className="submit-btn" onClick={onDecline}>Не</button>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="wrapper login-section chatbot">
      <form onSubmit={handleSubmit}>
        <div className={`form-row required ${errors.name ? 'error-fld' : ''}`}>
          <label htmlFor="name" className="label-form-fld">Име</label>
          <input
            type="text"
            className="form-fld"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <div className="border-bottom" />
          {errors.name && <div className="tooltip-div">{errors.name}</div>}
        </div>

        <div className={`form-row required ${errors.email ? 'error-fld' : ''}`}>
          <label htmlFor="email" className="label-form-fld">E-mail</label>
          <input
            type="text"
            className="form-fld"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <div className="border-bottom" />
          {errors.email && <div className="tooltip-div">{errors.email}</div>}
        </div>

        <div className={`form-row row-checkbox ${errors.agreed ? 'error-fld' : ''}`}>
          <input
            type="checkbox"
            className="form-fld"
            id="hr-checkbox"
            checked={agreed}
            onChange={(e) => setAgreed(e.target.checked)}
          />
          <label htmlFor="hr-checkbox" className="label-form-fld">
            Съгласен съм с{' '}
            <a href={termsUrl} className="conditions-link" target="_blank" rel="noopener noreferrer">
              General terms and Conditions
            </a>
          </label>
          {errors.agreed && <div className="tooltip-div">{errors.agreed}</div>}
        </div>

        <div className="form-row btn-row chatbot">
          <button type="submit" className="submit-btn">Изпрати</button>
          <button type="button" className="submit-btn" onClick={onDecline}>Не</button>
        </div>
      </form>
    </div>
  );
};
