import { useState, useEffect } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';

function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  // Close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  // Handle scroll for header state
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(prev => !prev);
  };

  const menuItems = {
    left: [
      { path: '/personality-test', label: 'Направи тест' },
      { path: '/chatbot', label: 'Robo' },
    ],
    right: [
      { path: '/Forum', label: 'Forum' }
    ]
  };

  return (
    <header className={`header ${isScrolled ? 'header--scrolled' : ''} ${isMobileMenuOpen ? 'header--menu-open' : ''}`}>
      <div className="header-wrap">
        {/* Mobile Header Row */}
        <div className="mobile-menu-row">
          <div className="mobile-logo-container">
            <Link to="/" className="mobile-logo-link">
              <img 
                src="/src/assets/icons/young-logo.svg" 
                alt="YoungStars logo" 
                className="template-image" 
              />
            </Link>
          </div>
          <div className="mobile-menu-container">
            <button 
              className={`menu-btn ${isMobileMenuOpen ? 'menu-btn--active' : ''}`}
              onClick={toggleMobileMenu}
              aria-label="Toggle menu"
              aria-expanded={isMobileMenuOpen}
            >
              <span className="lines-wrap">
                <span className="line line1"></span>
                <span className="line line2"></span>
                <span className="line line3"></span>
              </span>
            </button>
          </div>
        </div>

        {/* Desktop & Mobile Navigation */}
        <div className="header-box">
          <div className="header-box-inner">
            <nav className="nav">
              {/* Left Menu */}
              <ul className="menu menu-left">
                {menuItems.left.map(item => (
                  <li key={item.path} className="menu-item">
                    <NavLink 
                      to={item.path} 
                      className={({ isActive }) => `menu-link ${isActive ? 'active' : ''}`}
                    >
                      {item.isBold ? <strong>{item.label}</strong> : item.label}
                    </NavLink>
                  </li>
                ))}
              </ul>

              {/* Logo */}
              <h1 className="logo">
                <Link to="/" className="logo-link desktop">
                  <img src="/src/assets/icons/young-logo.svg" alt="YoungStars logo" />
                </Link>
              </h1>

              {/* Right Menu */}
              <ul className="menu menu-right">
                {menuItems.right.map(item => (
                  <li key={item.path} className="menu-item">
                    <NavLink 
                      to={item.path} 
                      className={({ isActive }) => `menu-link ${isActive ? 'active' : ''}`}
                    >
                      {item.isBold ? <strong>{item.label}</strong> : item.label}
                    </NavLink>
                  </li>
                ))}
              </ul>
            </nav>

            {/* Login Button */}
            <div className="login-container">
              <div className="login-container-inner">
                <div className="login-btn-wrap">
                  <Link to="/login" className="login btn">
                    Вход
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Header;
