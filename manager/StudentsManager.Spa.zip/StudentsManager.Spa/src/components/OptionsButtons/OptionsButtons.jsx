import React from 'react';
import './OptionsButtons.css';

export const OptionsButtons = ({ options, onSelect }) => {
  const getContainerClass = () => {
    switch (options.length) {
      case 1: return 'btn-1';
      case 2: return 'btn-2';
      case 3: return 'btn-3';
      default: return 'btn-n';
    }
  };

  return (
    <div className={`soge-btn-wrapper ${getContainerClass()}`}>
      {options.map((option, index) => (
        <span
          key={index}
          className="soge-btn"
          onClick={() => onSelect(index)}
        >
          <span className="btn-text">{option.text}</span>
          <div className="soge-btn-effect">
            <span className="effect-inner"></span>
          </div>
        </span>
      ))}
    </div>
  );
};
