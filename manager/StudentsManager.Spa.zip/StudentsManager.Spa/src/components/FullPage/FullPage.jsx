import { useState, useEffect, useRef, useCallback } from 'react';
import './FullPage.css';

function FullPage({ children, onSectionChange }) {
  const [activeSection, setActiveSection] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const containerRef = useRef(null);
  const sectionsCount = Array.isArray(children) ? children.length : 1;

  const goToSection = useCallback((index) => {
    if (isAnimating || index < 0 || index >= sectionsCount) return;
    
    setIsAnimating(true);
    setActiveSection(index);
    
    if (onSectionChange) {
      onSectionChange(index);
    }

    setTimeout(() => {
      setIsAnimating(false);
    }, 700);
  }, [isAnimating, sectionsCount, onSectionChange]);

  const handleWheel = useCallback((e) => {
    e.preventDefault();
    
    if (isAnimating) return;

    if (e.deltaY > 0) {
      goToSection(activeSection + 1);
    } else {
      goToSection(activeSection - 1);
    }
  }, [activeSection, goToSection, isAnimating]);

  const handleKeyDown = useCallback((e) => {
    if (e.key === 'ArrowDown' || e.key === 'PageDown') {
      e.preventDefault();
      goToSection(activeSection + 1);
    } else if (e.key === 'ArrowUp' || e.key === 'PageUp') {
      e.preventDefault();
      goToSection(activeSection - 1);
    }
  }, [activeSection, goToSection]);

  // Touch handling for mobile
  const touchStartY = useRef(0);
  
  const handleTouchStart = useCallback((e) => {
    touchStartY.current = e.touches[0].clientY;
  }, []);

  const handleTouchEnd = useCallback((e) => {
    const touchEndY = e.changedTouches[0].clientY;
    const diff = touchStartY.current - touchEndY;

    if (Math.abs(diff) > 50) {
      if (diff > 0) {
        goToSection(activeSection + 1);
      } else {
        goToSection(activeSection - 1);
      }
    }
  }, [activeSection, goToSection]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    container.addEventListener('wheel', handleWheel, { passive: false });
    container.addEventListener('touchstart', handleTouchStart, { passive: true });
    container.addEventListener('touchend', handleTouchEnd, { passive: true });
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      container.removeEventListener('wheel', handleWheel);
      container.removeEventListener('touchstart', handleTouchStart);
      container.removeEventListener('touchend', handleTouchEnd);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [handleWheel, handleKeyDown, handleTouchStart, handleTouchEnd]);

  return (
    <div className="fullpage" ref={containerRef}>
      <div 
        className="fullpage-wrapper"
        style={{ transform: `translateY(-${activeSection * 100}vh)` }}
      >
        {Array.isArray(children) ? (
          children.map((child, index) => (
            <section 
              key={index} 
              className={`fullpage-section ${index === activeSection ? 'active' : ''}`}
            >
              {child}
            </section>
          ))
        ) : (
          <section className="fullpage-section active">
            {children}
          </section>
        )}
      </div>
      
      {/* Page Navigation */}
      <PageNavigation 
        count={sectionsCount} 
        active={activeSection} 
        onNavigate={goToSection}
      />
    </div>
  );
}

function PageNavigation({ count, active, onNavigate }) {
  return (
    <div className="page-navigation">
      {Array.from({ length: count }).map((_, index) => (
        <button
          key={index}
          className={`page-nav-item ${index === active ? 'active' : ''}`}
          onClick={() => onNavigate(index)}
          aria-label={`Go to section ${index + 1}`}
        >
          <span className="page-slide">{index + 1}</span>
        </button>
      ))}
    </div>
  );
}

export default FullPage;
export { PageNavigation };
