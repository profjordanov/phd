import React, { useState } from 'react';
import './ScaleInput.css';

export const ScaleInput = ({ 
  onSelect, 
  min = 1, 
  max = 5 
}) => {
  const [hoverIndex, setHoverIndex] = useState(null);

  const buttons = Array.from({ length: max - min + 1 }, (_, i) => min + i);

  return (
    <div className="soge-scale" onMouseLeave={() => setHoverIndex(null)}>
      {buttons.map((value, index) => (
        <div
          key={value}
          className={`soge-scale-btn ${hoverIndex !== null && index <= hoverIndex ? 'hover' : ''}`}
          onMouseEnter={() => setHoverIndex(index)}
          onClick={() => onSelect(value)}
        >
          <div className="soge-scale-btn-label">{value}</div>
        </div>
      ))}
      <div 
        className="bg-fill" 
        style={{ 
          width: hoverIndex !== null 
            ? `${((hoverIndex + 1) / buttons.length) * 100}%` 
            : '0%' 
        }} 
      />
    </div>
  );
};
