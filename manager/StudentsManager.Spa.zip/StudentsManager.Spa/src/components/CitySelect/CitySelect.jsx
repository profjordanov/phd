import React, { useState } from 'react';
import _ from 'lodash';
import './CitySelect.css';

const CITIES = "Варна, София, Бургас, Пловдив, Айтос, Албена, Асеновград, Балчик, Банско, Бенковски, Благоевград, Ботевград, Велико Търново, Велинград, Враца, Гoце Делчев, Горна Оряховица, Габрово, Генерал Тошево, Гълъбово, Девин, Димитровград, Добрич, Доспат, Дулово, Дупница, Дългопол, Златоград, Исперих, Каварна, Казанлък, Карлово, Костинброд, Кубрат, Кърджали, Кюстендил, Ловече, Луковит, Монтана, Нова Загора, Пазарджик, Перник, Петрич, Пещера, Плевен, Попово, Провадия, Първомай, Раднево, Разград, Русе, Самоков, Сандански, Свиленград, Свищов, Своге, Севлиево, Силистра, Сливен, Смолян, Стамболойски, Стара Загора, Троян, Търговище, Харманли, Хасково, Червен бряг, Чирпан, Шумен, Ямбол, Тенево, Несебър, Боровец, Златни Пясъци, Слънчев бряг, друг"
  .split(',')
  .map(_.trim);

export const CitySelect = ({ onSelect }) => {
  const [selectedCity, setSelectedCity] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [hasError, setHasError] = useState(false);

  const handleSelect = (city) => {
    setSelectedCity(city);
    setIsOpen(false);
  };

  const handleSubmit = () => {
    if (_.trim(selectedCity)) {
      onSelect(selectedCity);
    } else {
      setHasError(true);
      setTimeout(() => setHasError(false), 500);
    }
  };

  const getMapsUrl = (city) => {
    const searchCity = city === 'друг' ? 'България' : city;
    return `https://www.google.bg/maps/search/"експресбанк"+OR+"Банка ДСК"+NEAR+"${searchCity}"`;
  };

  return (
    <div className="soge-select-wrapper">
      <div className={`soge-select ${hasError ? 'soge-shake' : ''}`}>
        <div className="label" onClick={() => setIsOpen(!isOpen)}>
          <span className="label-text">
            {selectedCity || 'Избери град'}
          </span>
          <div className="caret" />
        </div>
        <div className="soge-input-line" />
        
        {isOpen && (
          <div className="soge-list-wrapper open">
            <ul className="soge-list">
              {CITIES.map((city) => (
                <li key={city} onClick={() => handleSelect(city)}>
                  <span>{city}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      <button className="soge-btn btn-small" onClick={handleSubmit}>
        Избери
      </button>

      {selectedCity && (
        <a
          className="soge-btn no-m p15"
          href={getMapsUrl(selectedCity)}
          target="_blank"
          rel="noopener noreferrer"
        >
          Покажи на картата
        </a>
      )}
    </div>
  );
};
