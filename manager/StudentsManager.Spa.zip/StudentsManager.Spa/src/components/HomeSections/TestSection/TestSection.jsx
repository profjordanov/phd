import { Link } from 'react-router-dom';
import './TestSection.css';

function TestSection() {
  return (
    <div className="intro-test-section">
      <div className="section-box">
        <div className="intro-test-txt center">
          <div className="intro-test-txt-box white-box center">
            <div className="addition-txt-box">
              <span className="p-huge lightGrey addition-txt">Quiz</span>
            </div>
            <div className="wrap-txt">
              <h3 className="title-big black">
                Получи  <strong className="red">#точки</strong>?
              </h3>
              <p className="p-small">
                Довърши тестовете, които наподобяват викторина с въпроси.
              </p>
              <div className="curve-box">
                <Link to="/personality-test" className="btn-big btn-gray">
                  Тестове
                </Link>
              </div>
            </div>
          </div>
          
          <div className="image-item">
            <div className="boy-image">
              <img src="/src/assets/home/boy.png" alt="boy" className="template-image" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default TestSection;
