function IntroSection({ onScrollDown }) {
  return (
    <div className="intro-section">
      <div className="section-box">
        <div className="intro-txt center">
          <div className="intro-title-wrap">
            <h2 className="title-large white">
              Welcome to <strong className="white">#Students Manager</strong>
            </h2>
          </div>
          <p className="p-big white regular">
            Your journey to front end coding success starts here.
          </p>
        </div>
        
        <div className="scroll-down-container">
          <button 
            className="scroll-down-btn" 
            onClick={onScrollDown}
            aria-label="Scroll to next section"
          >
            <span className="scroll-down-image">
              <img src="/src/assets/icons/scroll-down.svg" alt="" className="template-image" />
            </span>
          </button>
        </div>
      </div>
      
      <div className="social-links-top-container">
      </div>
    </div>
  );
}

export default IntroSection;
