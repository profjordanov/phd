import { Link } from 'react-router-dom';
import './ChatbotSection.css';

function ChatbotSection() {
  return (
    <div className="chat-bot-section">
      <div className="section-box">
        <div className="intro-test-txt center">
          <div className="image-item">
            <div className="robot-image">
              <img src="/src/assets/home/robot.png" alt="robot" className="template-image" />
            </div>
          </div>
          
          <div className="intro-test-txt-box white-box center">
            <div className="addition-txt-box">
              <span className="p-huge lightGrey addition-txt">Chatbot</span>
            </div>
            <div className="wrap-txt">
              <h3 className="title-big black">
                Правил ли си #изпит с <strong className="red">чат бот</strong>?
              </h3>
              <p className="p-small">
                Запознай се с #ROBO и направи пробен изпит.
              </p>
              <div className="curve-box">
                <Link to="/chatbot" className="btn-big btn-gray">
                  Започни
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ChatbotSection;
