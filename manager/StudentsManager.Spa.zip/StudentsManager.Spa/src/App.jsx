import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout/Layout';
import HomePage from './pages/HomePage';
import ChatbotPage from './pages/ChatbotPage';
import PersonalityTestPage from './pages/PersonalityTestPage';
import LoginPage from './pages/LoginPage';

function App() {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<Layout />}>
                    <Route index element={<HomePage />} />
                    <Route path="chatbot" element={      <ChatbotPage
        submitUrl="/api/chatbot/save_results"
        isLoggedIn={false}
        termsUrl="/terms-and-conditions"
      />} />
                    <Route path="personality-test" element={<PersonalityTestPage />} />
                    <Route path="login" element={<LoginPage />} />
                </Route>
            </Routes>
        </Router>
    );
}

export default App;
