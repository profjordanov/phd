#!/bin/bash
docker-compose push