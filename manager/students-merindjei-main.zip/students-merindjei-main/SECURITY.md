# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 5.1.x   | :white_check_mark: |
| 5.0.x   | :x:                |
| 4.0.x   | :white_check_mark: |
| < 4.0   | :x:                |

## Reporting a Vulnerability
This section is being used to tell people how to report a vulnerability.
Plese, go and update the vulnerability report, the vulnerability will be either accepted or declined, etc.