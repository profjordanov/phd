# Students Manager

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/a37d37a1b7aa4c37b0a90ae37090ee08)](https://app.codacy.com/gh/profjordanov/students-manager?utm_source=github.com&utm_medium=referral&utm_content=profjordanov/students-manager&utm_campaign=Badge_Grade)
[![Build Status](https://travis-ci.com/profjordanov/students-manager.svg?branch=main)](https://travis-ci.com/profjordanov/students-manager)
[![GitHub issues](https://img.shields.io/github/issues/profjordanov/students-manager)](https://github.com/profjordanov/students-manager/issues)
[![GitHub license](https://img.shields.io/github/license/profjordanov/students-manager)](https://github.com/profjordanov/students-manager/blob/main/LICENSE)
[![University project](https://img.shields.io/badge/University%20of%20Economics-Varna-red)](https://www.ue-varna.bg/)

## Database Schema
![alt text](https://raw.githubusercontent.com/profjordanov/students-manager/master/docs/database_diagram.JPG)