/****** Script for SelectTopNRows command from SSMS  ******/
SELECT a.FullName, e.CourseExaminationId, u.Path
  FROM [dbo].[AspNetUsers] a
  LEFT JOIN[dbo].[StudentCourseExaminations] e
  ON e.UserId = a.Id
  LEFT JOIN [dbo].[StudentExaminationUploads] u
  ON e.Id = u.StudentCourseExaminationId


/****** Script for SelectTopNRows command from SSMS  ******/
SELECT a.FullName, u.FileName
  FROM [dbo].[StudentCourseExaminations] e
  inner join [dbo].[AspNetUsers] a
  on e.UserId = a.Id
  Left join [dbo].[StudentExaminationUploads] u
  on e.Id = u.StudentCourseExaminationId
  where u.FileName IS NULL
  
  
  SELECT e.Id, a.FullName, u.FileName
  FROM [dbo].[StudentCourseExaminations] e
  inner join [dbo].[AspNetUsers] a
  on e.UserId = a.Id
  Left join [dbo].[StudentExaminationUploads] u
  on e.Id = u.StudentCourseExaminationId
  where e.Score = 0

UPDATE [dbo].[StudentCourseExaminations]
   SET [Score] = 3
 WHERE [Id] = '834431B7-3032-480B-30CA-08D8F5939A53'
GO
