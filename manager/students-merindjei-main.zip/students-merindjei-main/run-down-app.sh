#!/bin/bash
docker-compose down