﻿namespace StudentsManager.Tests.Models;

public class AppSettingsRoot
{
    public ConnectionStrings ConnectionStrings { get; set; }
}