﻿namespace StudentsManager.Tests.Models;

public class ConnectionStrings
{
    public string DefaultConnection { get; set; }
}