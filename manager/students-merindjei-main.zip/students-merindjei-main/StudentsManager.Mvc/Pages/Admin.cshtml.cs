using Microsoft.AspNetCore.Mvc.RazorPages;

namespace StudentsManager.Mvc.Pages
{
    public class AdminModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}