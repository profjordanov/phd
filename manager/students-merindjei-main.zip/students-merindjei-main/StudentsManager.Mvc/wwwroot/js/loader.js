﻿$(document).ready(function() {
    $("body").addClass("loaded");
});