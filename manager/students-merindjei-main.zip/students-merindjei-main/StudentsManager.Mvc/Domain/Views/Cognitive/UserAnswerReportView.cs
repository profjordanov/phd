﻿namespace StudentsManager.Mvc.Domain.Views.Cognitive
{
    public class UserAnswerReportView
    {
        public string Report { get; set; }

        public string UserMail { get; set; }
    }
}