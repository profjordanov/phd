﻿namespace StudentsManager.Mvc.Domain.Entities
{
    public class CourseExaminationSetting
    {
        public int Id { get; set; }

        public string Type { get; set; }

        public bool Enabled { get; set; }
    }
}