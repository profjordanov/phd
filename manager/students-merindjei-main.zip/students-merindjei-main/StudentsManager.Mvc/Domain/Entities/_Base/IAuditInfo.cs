﻿namespace StudentsManager.Mvc.Domain.Entities._Base
{
    public interface IAuditInfo
    {
        DateTime CreatedOn { get; set; }
    }
}