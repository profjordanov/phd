﻿using Microsoft.AspNetCore.Identity;

namespace StudentsManager.Mvc.Domain.Entities
{
    public class Role : IdentityRole<Guid>
    {
    }
}