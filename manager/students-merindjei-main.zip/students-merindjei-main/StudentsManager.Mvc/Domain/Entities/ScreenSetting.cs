﻿namespace StudentsManager.Mvc.Domain.Entities
{
    public class ScreenSetting
    {
        public int Id { get; set; }

        public string Type { get; set; }

        public bool Enabled { get; set; }
    }
}