﻿namespace StudentsManager.Mvc.Domain.Inputs.Click
{
    public class UserAnswer
    {
        public string Question { get; set; }

        public object Answer { get; set; }
    }
}