﻿namespace StudentsManager.Mvc.Domain.Inputs.Click
{
    public class ClickResultsRootObject
    {
        public string Res { get; set; }

        public string Form { get; set; }
    }
}