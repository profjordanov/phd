﻿namespace StudentsManager.Mvc.Domain.Inputs.Forum
{
    public class Comment
    {
        public string Description { get; set; }

        public int ForumQuestionId { get; set; }
    }
}