﻿namespace StudentsManager.Mvc.Domain.Inputs
{
    public class ChosenOption
    {
        public int ChosenOptionId { get; set; }
    }
}