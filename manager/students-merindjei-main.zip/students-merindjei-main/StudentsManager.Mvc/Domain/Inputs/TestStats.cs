﻿namespace StudentsManager.Mvc.Domain.Inputs
{
    public class TestStats
    {
        public int Action { get; set; }

        public int Process { get; set; }

        public int People { get; set; }

        public int Idea { get; set; }
    }
}