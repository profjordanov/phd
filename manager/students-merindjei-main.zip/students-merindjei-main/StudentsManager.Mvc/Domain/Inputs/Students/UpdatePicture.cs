﻿namespace StudentsManager.Mvc.Domain.Inputs.Students
{
    public class UpdatePicture
    {
        public string FacultyNumber { get; set; }
        public string Password { get; set; }
        public string? Picture { get; set; }
    }
}