﻿using Newtonsoft.Json;

namespace StudentsManager.Mvc.Domain.Inputs
{
    public class TestAnswers
    {
        [JsonProperty("1")] public int First { get; set; }

        [JsonProperty("2")] public int Second { get; set; }

        [JsonProperty("3")] public int Third { get; set; }

        [JsonProperty("4")] public int Fourth { get; set; }

        [JsonProperty("5")] public int Fifth { get; set; }

        [JsonProperty("6")] public int Sixth { get; set; }

        [JsonProperty("7")] public int Seventh { get; set; }

        [JsonProperty("8")] public int Eighth { get; set; }

        [JsonProperty("9")] public int Ninth { get; set; }

        [JsonProperty("10")] public int Tenth { get; set; }

        [JsonProperty("11")] public int Eleventh { get; set; }

        [JsonProperty("12")] public int Twelfth { get; set; }

        [JsonProperty("13")] public int Thirteenth { get; set; }

        [JsonProperty("14")] public int Fourteenth { get; set; }

        [JsonProperty("15")] public int Fifteenth { get; set; }

        [JsonProperty("16")] public int Sixteenth { get; set; }

        [JsonProperty("17")] public int Seventeenth { get; set; }

        [JsonProperty("18")] public int Eighteenth { get; set; }

        [JsonProperty("19")] public int Nineteenth { get; set; }

        [JsonProperty("20")] public int Twentieth { get; set; }

        [JsonProperty("21")] public int TwentyFirst { get; set; }

        [JsonProperty("22")] public int TwentySecond { get; set; }

        [JsonProperty("23")] public int TwentyThird { get; set; }

        [JsonProperty("24")] public int TwentyFourth { get; set; }

        [JsonProperty("25")] public int TwentyFifth { get; set; }

        [JsonProperty("26")] public int TwentySixth { get; set; }

        [JsonProperty("27")] public int TwentySeventh { get; set; }

        [JsonProperty("28")] public int TwentyEighth { get; set; }

        [JsonProperty("29")] public int TwentyNinth { get; set; }

        [JsonProperty("30")] public int Thirtieth { get; set; }

        [JsonProperty("31")] public int ThirtyFirst { get; set; }

        [JsonProperty("32")] public int ThirtySecond { get; set; }

        [JsonProperty("33")] public int ThirtyThird { get; set; }

        [JsonProperty("34")] public int ThirtyFourth { get; set; }

        [JsonProperty("35")] public int ThirtyFifth { get; set; }

        [JsonProperty("36")] public int ThirtySixth { get; set; }

        [JsonProperty("37")] public int ThirtySeventh { get; set; }

        [JsonProperty("38")] public int ThirtyEighth { get; set; }

        [JsonProperty("39")] public int ThirtyNinth { get; set; }

        [JsonProperty("40")] public int Question40 { get; set; }
    }
}