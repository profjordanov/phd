﻿namespace StudentsManager.Mvc.Settings
{
    public class ServiceBusSettings
    {
        public string AzureConnectionString { get; set; }
        public string QueueName { get; set; }
    }
}