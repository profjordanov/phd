﻿namespace StudentsManager.Mvc.Settings
{
    public class StorageSettings
    {
        public string AzureConnectionString { get; set; }
        public string PathBasis { get; set; }
    }
}