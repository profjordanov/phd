﻿namespace StudentsManager.Mvc.Settings
{
    public class CognitiveSettings
    {
        public string Key { get; set; }
        public string Endpoint { get; set; }
    }
}