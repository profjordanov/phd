﻿namespace StudentsManager.Mvc.Services.CourseExaminations
{
    public static class CourseExaminationConstants
    {
        public const string FirstType = "First";
        public const string SecondType = "Second";
    }
}