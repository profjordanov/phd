﻿namespace StudentsManager.Mvc.Services.AppSettings
{
    public static class ScreenSettingConstants
    {
        public const string RegistrationScreenType = "RegistrationScreen";
    }
}