﻿namespace StudentsManager.Mvc.Services.Auth
{
    public static class AuthConstants
    {
        public const string LoginErrorMessage = "Мейлът или паролата са грешни! Моля, опитайте отново.";

        public const string RegisterErrorMessage =
            "Възникна проблем по време на създаване на потребител. Моля, опитайте отново!";

        public const string UnexpectedErrorMessage =
            "Възникна неочакван проблем. Моля, опитайте отново!";
    }
}